import React from "react";
import { Text, View, Image, StyleSheet } from "react-native";
import LikeButton from "./likeButton";
import Eye from "./eyeSlash";
import Comment from "./comment";
import Share from "./share";

export default function Users({image, userName, descriptionUser, titleComment, comment, navigation} ){
    return<View style = {styles.card}>
        <View style={{flexDirection: 'row'}}>
        <Image source={image} accessibilityLabel={userName} style={styles.image}/>
        <View style={styles.info}>
            <View style={{flexDirection: 'column'}}>
            <Text style={styles.userName}>{userName}</Text>
            <Text style={styles.descrption}>{descriptionUser}</Text>
            </View>
            </View>
            <LikeButton />
            </View>
            <Text style={styles.titleComment}>{titleComment}</Text>
            <Text style={styles.comment}>{comment}</Text>
            <Eye/>
            <View style={{flexDirection: 'row'}}>
            <Comment />
            <Share/>
            
            </View>
            </View>

            
   
   
}

const styles = StyleSheet.create({
    card: {
        backgroundColor: "white",
        marginVertical: 8,
        marginHorizontal: 16,
        borderRadius: 8,
        
        elevation: 4,
        shadowColor: '#000',
        shadowOffset: {
            width: 0,
            height: 2
        },
        shadowOpacity: 0.23,
        shadowRadius: 2.62
    },
    image: 
    {
        width: 60,
        height: 60,
        marginVertical: 8,
        marginLeft: 8
    },

    info:
    {
        flex: 1,
        flexDirection: 'row',
        justifyContent: 'space-between',
        marginLeft: 8,
        marginVertical: 16,
        marginRight: 20,
    },

    userName:
    {
        fontSize: 16,
        fontFamily: "NotoDisplayRegular",
        color: '#964D00',
       
    },

    descrption: {
        fontSize: 12,
        fontFamily: "NotoDisplayRegular",
        color: '#964D00',
        opacity: 0.5,
    },
    titleComment:
    {
        fontSize: 20,
       
        marginVertical: 8,
        marginHorizontal: 16,
        color: '#964D00',
        fontFamily: "NotoDisplayRegular",
    },
    comment: {
        fontSize:16,

        marginVertical: 8,
        color: '#964D00',
        fontFamily: "NotoDisplayRegular",
        marginLeft: 16,
      
        marginEnd: 20,
        opacity: 0.5
    },

  
    
})