import React from "react";
import { Dimensions, Image, StyleSheet, View } from "react-native";
import progress1 from '../../assets/request/Progress1.png';
import progress2 from '../../assets/request/Progress2.png';
import progress2On from '../../assets/request/Progress2-on.png';
import progress3 from '../../assets/request/Progress3.png';
import progress3On from '../../assets/request/Progress3-on.png';
import progress4 from '../../assets/request/Progress4.png';


const WIDTH = Dimensions.get('window').width;

function getPosition(indice) {
    const position = ((WIDTH / 5) * (indice)) - 15 - 20;
    console.log('getPosition ' + indice + ' ' + position );
    return Math.round(position);
}

function getProgressIcon(progress, i) {
    switch (i) {
        case 1:
            return progress1;
    
        case 2:
            if (progress < i) {
                return progress2;
            } else
                return progress2On;
                
        case 3:
            if (progress < i) {
                return progress3;
            } else
                return progress3On;

        case 4:
            return progress4;
            
        default:
            break;
    }
}

export default function ProgressRequest({progress}) {
    return (<View style={styles.container}>
        <View style={styles.line}></View>
        <View style={styles.background1}>
            <Image source={getProgressIcon(progress, 1)} style={styles.icon}/>
        </View>
        <View style={styles.background2}>
            <Image source={getProgressIcon(progress, 2)} style={styles.icon}/>
        </View>
        <View style={styles.background3}>
            <Image source={getProgressIcon(progress, 3)} style={styles.icon}/>
        </View>
        <View style={styles.background4}>
            <Image source={getProgressIcon(progress, 4)} style={styles.icon}/>
        </View>
    </View>);
}

const styles = StyleSheet.create({
    container: {
        padding: 20,
        height: 80,
        flexDirection: 'row',
        flex: 1
    },
    line: {
        flex: 1,
        top: 18,
        height: 2,
        backgroundColor: '#964D00'
    },
    icon: {
        width: 35,
        height: 41
    },
    background1: {
        backgroundColor: '#FFF1E2',
        position: 'absolute',
        width: 33,
        height: 50,
        top: 15,
        left: getPosition(1)
    },
    background2: {
        backgroundColor: '#FFF1E2',
        position: 'absolute',
        width: 33,
        height: 50,
        top: 15,
        left: getPosition(2)
    },
    background3: {
        backgroundColor: '#FFF1E2',
        position: 'absolute',
        width: 33,
        height: 50,
        top: 15,
        left: getPosition(3)
    },
    background4: {
        backgroundColor: '#FFF1E2',
        position: 'absolute',
        width: 33,
        height: 50,
        top: 15,
        left: getPosition(4)
    },
})