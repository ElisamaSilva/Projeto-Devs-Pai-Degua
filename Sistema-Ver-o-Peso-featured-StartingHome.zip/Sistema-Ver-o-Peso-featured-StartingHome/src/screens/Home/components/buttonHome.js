import { StyleSheet, TouchableOpacity,Text, View } from 'react-native';
import React from 'react';


export default function ButtonHome({ title }){ 
    return <>
    
     <TouchableOpacity style = {styles.button}>
        <Text style = { styles.textButton }>{ title }</Text>
     </TouchableOpacity>
   
     </>
}

const styles = StyleSheet.create({
    button: {
        padding: 10,
        backgroundColor: '#964D00',

        borderRadius: 50,
        margin: 10,
    

        width:120,
        height:50,
        alignItems: 'center',
        justifyContent: 'center',
    },
        
    textButton: {
        textAlign: "center",
        fontSize: 16,

        color: "white",

        alignSelf:'center',
        fontFamily: "NotoRegular",

    }
           
    })