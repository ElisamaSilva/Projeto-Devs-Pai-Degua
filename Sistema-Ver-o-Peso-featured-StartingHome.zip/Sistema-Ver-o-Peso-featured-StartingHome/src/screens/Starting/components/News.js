import React from 'react';
import { Platform, View, Text, Dimensions, Image, StyleSheet } from 'react-native';

import Card from '../../../components/Card';

const width = Dimensions.get('screen').width

export default function News({ title, content}){
    return <View style = {styles.body}>
        <Card title={title}>{content}</Card>
    </View>
        
};

const styles = StyleSheet.create({
    map:{
        ...Platform.select({
            web: {
                width: "100%",
                height: 299
            },
            android: {
                width: "100%",
                height: 578 / 768 * width,
            }
        }),
    }
})