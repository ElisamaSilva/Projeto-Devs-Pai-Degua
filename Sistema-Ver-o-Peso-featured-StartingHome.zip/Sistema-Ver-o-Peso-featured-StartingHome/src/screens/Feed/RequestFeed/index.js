import { useState } from "react";
import { View, Text, StyleSheet, SafeAreaView, ScrollView, KeyboardAvoidingView, Pressable } from "react-native";
import { useNavigation } from "@react-navigation/native";
import Publish from "../components/publish.js";
import Searchbar from "../components/search.js";
import Plus from "../buttonPlus";
import { Ionicons } from '@expo/vector-icons';


export default function RequestFeed({navigation})
{
   
    const Navigation = useNavigation();
    const [value, setValue] = useState()
    function UpdateSearch(value) {
        console.log(value)
    }
    return(
    <ScrollView style={{backgroundColor: '#FFF1E2'}}>
      <SafeAreaView >
      
            <Publish/>
            
            <View style={{flexDirection:'row'}}>
            <Searchbar value={value} updateSearch={UpdateSearch}/>
            <Plus onPress={() => navigation.navigate('REQUEST')}/>
            </View>
            <View style={{flexDirection:"row"}}>
            <Pressable style={styles.button} onPress={() => navigation.navigate('FEED')}>
                <View style={{flexDirection:'row'}}>
                <Ionicons name="home-outline" size={28} color="white"/>
                <Text style={styles.text}>Feed</Text>
                </View>
            </Pressable>

            <Pressable style={styles.buttonReq} onPress={() => navigation.navigate('REQUEST_FEED')}>
                <View style={{flexDirection:'row'}}>
                <Ionicons name="megaphone-outline" size={28} color="#964D00"/>
                <Text style={styles.textReq}>Request</Text>
                </View>
            </Pressable>
            </View>
           
            
            
        </SafeAreaView>
       
    </ScrollView>
    )



};



const styles = StyleSheet.create({
   button: 
   {
    padding: 10,
    backgroundColor: "#964D00",
    height: 60,
    width: '40%',
    marginHorizontal: 20,
    marginVertical: 8,
    borderRadius: 5,
    justifyContent:'center',

   },
   text: {
    fontFamily: 'NotoDisplayRegular',
    fontSize: 16,
    marginHorizontal: 30,
    marginVertical: 8,
    color: "white",
    textAlign: 'center',
    justifyContent:'center',
    
   },
   buttonReq: {
    padding: 10,
    borderColor: "#964D00",
    height: 60,
    width: '40%',
    marginHorizontal: 20,
    marginVertical: 8,
    borderRadius: 5,
    justifyContent:'center',
    borderWidth: 2
   },

   textReq: {
    fontFamily: 'NotoDisplayRegular',
    fontSize: 16,
    marginHorizontal: 30,
    marginVertical: 8,
    color: "#964D00",
    textAlign: 'center',
    justifyContent:'center',
   }
    
})