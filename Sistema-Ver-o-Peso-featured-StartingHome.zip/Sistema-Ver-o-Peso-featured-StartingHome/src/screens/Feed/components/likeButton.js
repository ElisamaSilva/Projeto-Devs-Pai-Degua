import React, { useState } from "react";
import { StyleSheet } from "react-native";
import { Pressable } from "react-native";
import {  AntDesign} from '@expo/vector-icons'

export default function LikeButton () {
  const [liked, setLiked] = useState();
 

  

  return (
    <Pressable onPress={() => setLiked((isLiked) => !isLiked)} style={styles.like}>
    <AntDesign
      name={liked ? "like1": "like2" }
      size={32}
      color={liked ? "#7B2B09" : "#7B2B09"}
      
    />
  </Pressable>
  
  );
};

const styles = StyleSheet.create({
  like: {
    padding: 16
  }
})

