const RequestDetails = {
    seller: {
        name: "Paula Souza",
        photo: require('../../assets/Persona.png'),
        ocupation: "Oil Seller",
        posted: "2d",
    },
    agent: {
        name: "Sophia Ava Gardner",
        photo: require('../../assets/agent.png'),
        ocupation: "Gov. Agent",
        posted: "5h",
    },
    title: "A lot of food wasted",
    votes: 71,
    is_public: true,
    details: "For many people in the world, food waste has become a habit: buying more food than we need at markets, letting fruits and vegetables spoil at home or taking larger portions than we can eat.",
    progress: 1,
    chat: [
        {
            id: 1,
            author: {
                name: "Paula Souza",
                photo: require('../../assets/agent.png'),
                ocupation: "Oil Seller",
                posted: "5h"
            },
            content: "Hope that it wont take to long for we to figure out something to solve this"
        }
    ],
    tags: [
        {
            id: 1,
            name: "Food"
        },
        {
            id: 2,
            name: "Garbage"
        },
        {
            id: 3,
            name: "Infra"
        }
    ]
}

export default RequestDetails;