import React from 'react'
import { TouchableOpacity, StyleSheet } from 'react-native'
import { Ionicons} from '@expo/vector-icons'

export default function Share(){
    return<>
    <TouchableOpacity onPress={() => navigation.navigate('') } style={styles.share}>
    <Ionicons name="share-social-outline" size={32} color="#964D00" />
    </TouchableOpacity>
   
    </>
}

const styles = StyleSheet.create({
    share: {
        flex: 1,
        flexDirection: 'row',
        justifyContent: 'space-between',
        marginLeft: 8,
        marginVertical: 16,
        marginRight: 20,
        left: 200
    },
    shareText: 
    {
        fontSize:16,
        fontFamily: 'NotoDisplayRegular',
        
    }
})
 