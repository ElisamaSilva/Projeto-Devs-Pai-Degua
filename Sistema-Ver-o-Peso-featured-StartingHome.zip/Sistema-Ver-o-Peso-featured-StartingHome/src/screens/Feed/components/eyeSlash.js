import React, { useState } from "react";
import { StyleSheet } from "react-native";
import { Pressable } from "react-native";
import { Ionicons } from '@expo/vector-icons'

export default function Eye () {
  const [liked, setLiked] = useState();
 

  

  return (
    <Pressable onPress={() => setLiked((isLiked) => !isLiked)} style={styles.eye}>
    <Ionicons
      name={liked ? "eye-outline": "eye-off-outline" }
      size={32}
      color={liked ? "#964D00" : "#964D00"}
      
    />
  </Pressable>
  
  );
};

const styles = StyleSheet.create({
  eye: 
    {
        alignItems: 'center',
       
    }
})
