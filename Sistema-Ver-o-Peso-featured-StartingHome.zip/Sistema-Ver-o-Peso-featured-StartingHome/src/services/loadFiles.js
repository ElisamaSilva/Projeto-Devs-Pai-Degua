import aboutText from '../mocks/aboutText.js';
import aboutImages from '../mocks/aboutImages.js';
import StartingNews from '../mocks/StartingNews.js';
import RequestDetails from '../mocks/RequestDetails.js';
import publish from '../mocks/publish.js';
import request from '../mocks/request'

export const loadAboutText = () => {
    return aboutText;
};
export const loadAboutImages = () => {
    return aboutImages;
};
export const loadNewsList = () => {
    return StartingNews;
};
export const loadStoreItens = () => {
    return StoreItens;
};

export const loadPublish= () => {
    return publish;
}

export const loadRequestDetails=() =>{
    return RequestDetails;
}

export const LoadRequest=()=>{
    return request;
}