import React from "react";
import { Dimensions, FlatList, View} from 'react-native';

const width = Dimensions.get('window');

const ButtonSlider = ({data}) => {
    return <>
        <FlatList
            data = {data}
            keyExtractor = {(item) => String(item)}
            showsHorizontalScrollIndicator = {false}
            horizontal 
            snapToAlignment={"start"}
            renderItem={({item})=>  (
                <View style = {{
                backgroundColor: item,
                height: width/2.6,
                width,
            }}
            />
        )}
        />
    </>
}

export default ButtonSlider;

