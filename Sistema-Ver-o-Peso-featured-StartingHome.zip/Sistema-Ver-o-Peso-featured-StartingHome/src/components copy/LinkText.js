import { Text, StyleSheet } from "react-native"

export default function LinkText( {content} ) {
    return <Text style={styles.content}>{ content }</Text>
}

const styles = StyleSheet.create({
    content: {
        fontFamily: "NotoRegular",
        textDecorationLine:"underline",
        alignSelf: 'flex-end',
        fontSize: 16,
        lineHeight: 21,
        color: '#BF7526',
        marginHorizontal: 15,
        marginBottom: 10,
    },
})