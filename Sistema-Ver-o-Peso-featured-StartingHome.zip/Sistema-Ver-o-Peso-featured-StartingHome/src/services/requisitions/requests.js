import { Title } from "react-native-paper";
import api from "../api"
import { authenticated } from "./auth";

//todos as solicitacoes nao privadas
export async function publicRequests(){
    const id = (await authenticated()).seller.id
    //const id = await authenticated()['seller']['id']

    try{
        const requests = (await api.get( 
            `/sellers/${id}/requests`
        )).data;


        console.log(requests)

        return {
            requests
        }
    }
    catch (error){
        console.log(error)
        return {}
    }
}

//mostra solicitacao por id
export async function showRequest(id){

    try{
        const request = (await api.get( 
            `/requests/${id}`
        )).data;


        console.log(request)

        return {
            request
        }
    }
    catch (error){
        console.log(error)
        return {}
    }
}

//resgistro de solicitacao
export async function storeRequest(Title,Content,IsPrivate){
    const id = (await authenticated()).seller.id
    let request = {
        'title': Title,
        'content': Content,
        'isPrivate': IsPrivate
    }
    //console.log(id)


    try{
        await api.post( 
            `sellers/${id}/requests`, request
        );

        //console.log(request)

        return {
            request
        }
    }
    catch (error){
        console.log(error)
        return {}
    }
}

//edit de solicitacao
export async function editRequest(id,Title,Content,IsPrivate){
    
    let request = {
        'title': Title,
        'content': Content,
        'isPrivate': IsPrivate
    }


    try{
        await api.put( 
            `/requests/${id}`, request
        );

        //console.log(request)

        return {
            request
        }
    }
    catch (error){
        console.log(error)
        return {}
    }
}