import api from "../api"

//todos os feirantes
export async function indexSellers(){
    try{
        const request = await api.get( 
            '/sellers'
        );

        const sellers = request.data

        //console.log(sellers)

        return {
            sellers
        }
    }
    catch (error){
        console.log(error)
        return {}
    }
}

//Feirante por id
export async function showSeller(id){
    try{
        const request = await api.get( 
            `/sellers/${id}`
        );

        const seller = request.data

        //console.log(seller)

        return {
            seller
        }
    }
    catch (error){
        console.log(error)
        return {}
    }
}

//Request de um feirante por id
export async function sellersRequests(id){
    try{
        const seller = await show(id)

        const requests = seller['seller']['requests']

        //console.log(requests)

        return {
            requests
        }
    }
    catch (error){
        console.log(error)
        return {}
    }
}

//resgistro do feirante
export async function storeSeller(Name,Email,Password,Phone,Photo){
    let seller = {
        'name': Name,
        'email': Email,
        'password': Password,
        'phone': Phone,
        'photo':Photo
    }
    //console.log(seller)


    try{
        const request = await api.post( 
            '/sellers', seller
        );

        //console.log(request)

        return {
            request
        }
    }
    catch (error){
        console.log(error)
        return {}
    }
}

//edit do feirante
export async function editSeller(Name,Email,Password,Phone,Photo,id){
    let seller = {
        'name': Name,
        'email': Email,
        'password': Password,
        'phone': Phone,
        'photo':Photo
    }
    //console.log(seller)


    try{
        const request = await api.put( 
            `/sellers/${id}`, seller
        );

        //console.log(request)

        return {
            request
        }
    }
    catch (error){
        console.log(error)
        return {}
    }
}