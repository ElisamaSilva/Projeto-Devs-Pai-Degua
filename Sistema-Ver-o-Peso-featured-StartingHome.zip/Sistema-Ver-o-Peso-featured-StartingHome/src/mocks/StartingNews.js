const content = {
    contentList:[
        {
            title: "New Stores:",
            content: "We're always exploring locations for new stores. But how do we decide where to open a new store? We look at a number of factors, like how we can best meet a community’s needs, site constraints, other area stores and more."
        },
        {
            title: "Test",
            content: "This is NOT a test, don't belive the title"
        },
    ]
};

export default content;