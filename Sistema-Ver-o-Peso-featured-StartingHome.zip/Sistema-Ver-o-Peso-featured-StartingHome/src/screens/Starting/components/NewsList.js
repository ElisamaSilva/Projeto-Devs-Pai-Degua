import React , { useEffect, useState } from 'react';
import { Image, Text, FlatList, View, StyleSheet, Dimensions } from 'react-native';

import Logo from '../../../../assets/Ver-o-peso_logo.png'

import { loadNewsList } from '../../../services/loadFiles.js';
import Button from "../../../components/Button.js"
import TitleText from '../../../components/TitleText.js';
import News from './News.js';

const width = Dimensions.get('screen').width

export default function NewsList({ navigation }) {   
  const [contentList, setList] = useState([]);

  useEffect(() => {
      const loadItem = loadNewsList();
      setList(loadItem.contentList);
  }, []);

  const listHeader = () => {
    return <>
        <View style={styles.body}>

            <Image source={Logo} style={styles.logo}/>
            <Text style={{fontFamily: "NotoDisplayRegular", fontSize:30, color: "#964D00"}}>VER-O-PESO</Text>
                <View style={styles.buttonRow}>
                    <View style={styles.button}>
                        <Button title="Start" onPress={() => navigation.navigate('LOGIN')}/>
                    </View>
                    <View style={styles.button}>
                        <Button title="About" onPress={() => navigation.navigate('ABOUT')}/>
                    </View>
                </View>
            </View>
            
        <TitleText content={"News"}/>
    </>
    }

  return <FlatList
      data = { contentList }
      renderItem = {({ item }) => <News {...item}/>}
      keyExtractor = {({title}) => title}
      ListHeaderComponent = {listHeader} 
       />
};

const styles = StyleSheet.create({
    
    logo:{
        width: 188,
        height: 283,
    },
    body:{
        alignItems: 'center',
        justifyContent: 'center',
        marginTop:100,
    },
    
    buttonRow:{
        marginVertical:20,
        padding: 20
    },
    button:{
        padding:10
    },
    
})
