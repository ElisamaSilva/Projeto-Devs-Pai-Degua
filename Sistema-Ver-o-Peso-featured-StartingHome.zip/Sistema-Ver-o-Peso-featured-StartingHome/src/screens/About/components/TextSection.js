import React from 'react';
import { Platform, View, Text, Dimensions, Image, StyleSheet } from 'react-native';

import TitleText from '../../../components/TitleText.js';
import NormalText from '../../../components/NormalText.js';

const width = Dimensions.get('screen').width

export default function TextSection({ title, image, content}){
    if ( image ){
        return <View style = {styles.body}>
            <TitleText content={title}/>
            <Image style = {styles.map} source={image}/>
            <NormalText content={content}/>
        </View>
    }

    return <View style = {styles.body}>
        <TitleText content={title}/>
        <NormalText content={content}/>
    </View>
        
};

const styles = StyleSheet.create({
    map:{
        marginHorizontal: 16,
        ...Platform.select({
            web: {
                width: "100%",
                height: 299,
                
            },
            android: {
                width: "100%",
                height: 578 / 768 * width,
            }
        }),
    }
})