import React , { useEffect, useState } from 'react';
import { Image, View, FlatList, StyleSheet } from 'react-native';

import { loadStoreItens } from '../../../services/loadFiles.js';
import ItemCard from './ItemCard.js';

import { Icon } from 'react-native-elements';

import logo from '../../../../assets/stores/saborBarista.png'

export default function ItemCards({}) {
    const [list, setList] = useState([]);

    useEffect(() => {
        const loadItem = loadStoreItens();
        setList(loadItem.StoreItensList);

    }, []);

    const listHeader = () => {
        

        return <>
            <Image source={logo} style={styles.logo}/>
            <View style={{flexDirection:"row", alignSelf: "center", marginVertical:10}}>
                <Icon name={ "star" }  size={20} color="#964D00"  type='feather' />
                <Icon name={ "star" }  size={20} color="#964D00"  type='feather' />
                <Icon name={ "star" }  size={20} color="#964D00"  type='feather' />
                <Icon name={ "star" }  size={20} color="#964D00"  type='feather' />
                <Icon name={ "star" }  size={20} color="#964D00"  type='feather' />
            </View>
        </>
    }

    return <FlatList
        data = { list }
        renderItem = {({ item }) => <ItemCard {...item}/>}
        keyExtractor = {({title}) => title}
        ListHeaderComponent = {listHeader} />
};

const styles = StyleSheet.create({
    logo:{
        width:84,
        height:84,
        alignSelf: "center"
    },

})