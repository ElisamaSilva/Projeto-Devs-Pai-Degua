import React from "react";
import { View, Text, Image, StyleSheet, ScrollView, Pressable } from "react-native";

import { Icon } from 'react-native-elements';

import TitleText from "../../components/TitleText.js"
import NormalText from "../../components/NormalText.js"
import LinkText from "../../components/LinkText.js"
import Item from "../../components/Item.js"

import logo from '../../../assets/stores/saborBarista.png'
import map from '../../../assets/about/map.png'

import espresso from '../../../assets/itens/photos/espresso.png'
import GreenTea from '../../../assets/itens/photos/greenTea.png'
import Black from '../../../assets/itens/photos/black.png'

export default function Store({navigation}){

    return(<ScrollView style={{backgroundColor: '#FFF1E2', width: "100%"}}>
        <Image source={logo} style={styles.logo}/>
        <View style={{flexDirection:"row", alignSelf: "center", marginVertical:10}}>
            <Icon name={ "star" }  size={20} color="#964D00"  type='feather' />
            <Icon name={ "star" }  size={20} color="#964D00"  type='feather' />
            <Icon name={ "star" }  size={20} color="#964D00"  type='feather' />
            <Icon name={ "star" }  size={20} color="#964D00"  type='feather' />
            <Icon name={ "star" }  size={20} color="#964D00"  type='feather' />
        </View>
        <View style={{flexDirection:"row", justifyContent:"space-between"}}>
            <TitleText content={"PRODUCTS"}/>
            <Pressable  style={{flexDirection:"row", justifyContent:"space-between", marginRight:15}} onPress={() => navigation.navigate('CATALOG')}>
                <LinkText content={"Show more"}/>
            </Pressable>
        </View>
        <Item name={"Espresso"} image={espresso} listPrice={"List price: $7,00"} onPress={() => navigation.navigate('ITEM')}/>
        <Item name={"Green"} image={GreenTea} listPrice={"List price: $7,00"} />
        <Item name={"Black"} image={Black} listPrice={"List price: $8,25"} />
        <View>
            <TitleText content={"Location"}/>
            <Image source={map} style={{backgroundColor: 'red', width: "100%"}}/>
    
        </View>
        <View >
            <TitleText content={"About"}/>
            <NormalText content={"A coffeehouse, coffee shop, or café is an establishment that primarily serves coffee of various types, notably espresso, latte, and cappuccino."}/>
            <NormalText content={"Payments: Pix, credit & debit cards\nPhone: +55 (91) 3265 - 4321\nWhatsapp: +55 (91) 9 8765 - 4321"}/>
        </View>
    </ScrollView>
    

    )
    
}

const styles = StyleSheet.create({
    logo:{
        width:84,
        height:84,
        alignSelf: "center"
    },
})