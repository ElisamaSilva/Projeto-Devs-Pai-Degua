import React, { useEffect, useState } from "react";
import { FlatList, ScrollView, StyleSheet, View } from "react-native";
import NormalText from "../../components/NormalText";
import TitleText from "../../components/TitleText";

import { loadRequestDetails } from "../../services/loadFiles.js";
import { Image } from "react-native";
import NormalTextRequest from "../../components/NormalTextRequest";
import PublishedByRequest from "../../components/PublishedByRequest";
import ProgressRequest from "../../components/ProgressRequest";
import ButtonMakePublic from "../../components/ButtonMakePublic";
import ButtonConfirm from "../../components/ButtonConfirm";
import ButtonMakeChanges from "../../components/ButtonMakeChanges";
import Chat from "../../components/Chat";

export default function RequestDetailsScreen({navigation}) {
    
    const loadItem = loadRequestDetails();
    
    return (<ScrollView style={{backgroundColor: '#FFF1E2'}}>
        <View style={styles.body}>
        <View style={styles.login}>
            <TitleText content={"PUBLISHED BY"}/>
            <PublishedByRequest request={loadItem} />
            <TitleText content={"ABOUT"}/>
            <NormalTextRequest content={loadItem.details}/>
            <TitleText content={"PROGRESS"}/>
            <ProgressRequest progress={loadItem.progress}/>
            <TitleText content={"OPTIONS"}/>
            <View style={styles.buttonRow}>
                <ButtonMakePublic title="Make Public" />
                <ButtonMakeChanges title="Make Changes" />
            </View>
            <TitleText content={"CHAT"}/> 
            <Chat chat={loadItem.chat}/>
        </View>
    </View>
    </ScrollView>);
}

const styles = StyleSheet.create({
    
    body:{
        alignItems: 'flex-start',
        justifyContent: 'flex-start',
        backgroundColor: '#FFF1E2'
    },
    login:{
        alignItems: "flex-start",
        marginTop:20,
    },  
    buttonRow:{
        flexDirection: "row",
        alignItems: 'center',
    },
    buttonConfirmRow: {
        flexDirection: "row-reverse",
        paddingTop: 20,
    },
    button:{
        padding:10
    },
})