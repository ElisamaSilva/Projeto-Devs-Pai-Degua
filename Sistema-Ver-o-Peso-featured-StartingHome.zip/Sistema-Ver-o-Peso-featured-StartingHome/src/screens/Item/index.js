import react from "react"
import { ScrollView, StyleSheet, Platform, Dimensions, View, Image, Text } from "react-native"

import logo from '../../../assets/stores/saborBarista.png'
import image from '../../../assets/itens/photos/espresso.png'

//import { Icon } from 'react-native-elements';

import Button from "../../components/Button.js"

import NormalText from "../../components/NormalText"
import TitleText from "../../components/TitleText.js"
import { Icon } from "react-native-elements"

const width = Dimensions.get('screen').width



export default function ItemScreen({ navigation }) {
    return (
        <ScrollView style={{backgroundColor: '#FFF1E2'}}>
            <Image source={logo} style={styles.logo}/>
            <View style={{flexDirection:"row", alignSelf: "center", marginVertical:10}}>
                <Icon name={ "star" }  size={20} color="#964D00"  type='feather' />
                <Icon name={ "star" }  size={20} color="#964D00"  type='feather' />
                <Icon name={ "star" }  size={20} color="#964D00"  type='feather' />
                <Icon name={ "star" }  size={20} color="#964D00"  type='feather' />
                <Icon name={ "star" }  size={20} color="#964D00"  type='feather' />
            </View>
            <View>
                <Image source={image} style={styles.image}/>
                <View style={{flexDirection:"row", justifyContent:"space-between", marginRight:15}}>
                    <TitleText content={"Espresso"}/>
                    <View style={{flexDirection:"row", marginVertical:7}}>
                        <Icon name={ "star" }  size={20} color="#964D00"  type='feather' />
                        <Icon name={ "star" }  size={20} color="#964D00"  type='feather' />
                        <Icon name={ "star" }  size={20} color="#964D00"  type='feather' />
                        <Icon name={ "star" }  size={20} color="#964D00"  type='feather' />
                        <Icon name={ "star" }  size={20} color="#964D00"  type='feather' />
                    </View>
                </View>
                
                <NormalText content={"Espresso is a coffee-brewing method of Italian origin, in which a small amount of nearly boiling water (about 90 °C or 190 °F) is forced under 9–10 bars (900–1,000 kPa; 130–150 psi) of pressure through finely-ground coffee beans."}/>
                <Text style={styles.price}>{ "List price: $7.00" }</Text>
            </View>
        </ScrollView>
    )
}

const styles = StyleSheet.create({
    logo:{
        width:84,
        height:84,
        alignSelf: "center"
    },
    image:{
        ...Platform.select({
            web: {
                width: "100%",
                height: 299
            },
            android: {
                width: "100%",
                height: 578 / 768 * width,
            }
        }),
    },
    price:{
        fontFamily: "NotoRegular",
        fontWeight:'bold',
        fontSize: 16,
        lineHeight: 21,
        color: '#964D00',
        marginHorizontal: 15,
        marginBottom: 10,
    }

})