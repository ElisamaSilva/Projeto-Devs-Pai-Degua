import React from "react";
import {Pressable, StyleSheet } from 'react-native'
import { Entypo} from '@expo/vector-icons'

export default function Plus({onPress}){
    return(
    <Pressable onPress={onPress} style={styles.button}>
            <Entypo name="plus" size={24} color="white" />
    </Pressable>
    )       
}

const styles = StyleSheet.create({
    button: {
      alignItems:'center',
      justifyContent:'center',
      width:50,
      height:50,
      backgroundColor:'#964D00',
      borderRadius:5,

      margin:20,
    
      shadowColor: 'rgba(150, 77, 0, 0.7)',
      shadowOffset: { width: 0, height: 2 },
      shadowRadius: 10,
      right: 40
      
    }
  });