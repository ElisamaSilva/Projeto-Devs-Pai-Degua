import React from 'react';
import { Platform, Text, View, StyleSheet, Pressable } from 'react-native';

export default function ButtonConfirm({ onPress, title }) {
  return (
    <Pressable style={styles.button} onPress={onPress}>
      <Text style={styles.text}>{ title }</Text>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  button: {
    width:164,
    height:48,

    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 12,
    paddingHorizontal: 32,
    borderRadius: 30,
    backgroundColor: '#964D00',

    marginHorizontal:15,
    
    shadowColor: 'rgba(150, 77, 0, 0.7)',
    shadowOffset: { width: 0, height: 2 },
    shadowRadius: 10,
  },
  text: {
    fontFamily: "NotoRegular",
    fontSize: 16,
    lineHeight: 21,
    letterSpacing: 0.25,
    color: '#FFF1E2',
  },
});