import react from "react"
import { Platform, Image, StyleSheet, Text, Dimensions, ScrollView, View, Linking } from "react-native"

import TextSections from "./components/TextSections.js"


export default function AboutScreen({ navigation }) {

    return (<View style={styles.body}>
            <TextSections/>
        </View>
    )
}

const styles = StyleSheet.create({
    
    body:{
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: '#FFF1E2'
    },
    
})