import { useState, useEffect } from "react";
import { loadPublish } from "../services/loadFiles";

export default function UseUsers(){
    const [title, setTitle] = useState('');
    const [publication,setPublication] = useState([]);

    useEffect(()=>{
        const back = loadPublish();
        setTitle(back.title);
        setPublication(back.publication);
        console.log(back)
    }, []);

    return [title, publication]
}