import userCarlos from '../../assets/feed/userCarlos.png';
import userJoana from  '../../assets/feed/userJoana.png';

const publish= {
    title: "REQUEST ",
    publication: 
    [
        {   
            image: userCarlos,
            userName: "Carlos Reis",
            descriptionUser: "Food Seller - 40m",
            titleComment: "She's Leaving Home",
            comment: "Wednesday morning at five o'clock as the day begins, silently closing her bedroom door, Leaving the note that she hoped would say more.",
        },

        {
            image: userJoana,
            userName: "Love und Romance",
            descriptionUser: "Food Seller - 2hr",
            titleComment: "Soma",
            comment: "We can get married and have a house in the country...Love's a feeling... and so is stealing, Do ya hear me? I hear ya!"
        }
    ]
} 
   

export default publish;