import api from "../api"

//todos os noticias
export async function indexNews(){
    try{
        const request = await api.get( 
            '/news'
        );

        const news = request.data

        //console.log(sellers)

        return {
            news
        }
    }
    catch (error){
        console.log(error)
        return {}
    }
}
