import React, {useEffect, useState} from "react";
import { Text, View, StyleSheet, FlatList} from 'react-native';
import { loadPublish } from "../../../services/loadFiles";
import Users from "./users";
import UseUsers from "../../../Hooks/useUsers";

export default function Publish(){

    const [title,publication] = UseUsers();
    
    return(
    <FlatList 
    data = {publication}
    renderItem={({item})=><Users {...item}/>}
    keyExtractor={({userName})=> userName}
    ListHeaderComponent={()=> <Text style = {styles.title}>{title}</Text>}
    />
        )
    
};


const styles = StyleSheet.create({
    title: {
        fontFamily: "NotoDisplayRegular",
        color: "#964D00",
        fontSize: 24, 
        padding: 18,
        lineHeight: 42
    },

    userName: {
        fontSize: 20,
        lineHeight: 32,
        marginHorizontal: 16,
        marginTop: 16,
        fontFamily: "NotoDisplayRegular"
    }
})