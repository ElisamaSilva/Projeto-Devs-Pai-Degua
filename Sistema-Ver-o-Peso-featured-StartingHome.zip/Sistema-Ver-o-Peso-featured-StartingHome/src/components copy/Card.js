import React from 'react';
import { Platform, StyleSheet, View, Text } from 'react-native';
import NormalText from './NormalText';

export default function Card({title, children}) {
  return (
    <View style={styles.card}>
        <View style={styles.cardContent}>
            <NormalText content={title}/>
            <NormalText content={children}/>
        </View>
    </View>
  );
}

const styles = StyleSheet.create({
    card: {
        borderRadius: 6,
        elevation: 3,
        backgroundColor: 'white',
        
        shadowColor: 'rgba(150, 77, 0, 0.5)',
        shadowOffset: { width: 0, height: 2 },
        shadowRadius: 10,
        height: "auto",
        marginVertical: 10,
        marginHorizontal: 15,
    },
    cardContent: {
        paddingHorizontal:10,
        paddingVertical:15,
    },
});