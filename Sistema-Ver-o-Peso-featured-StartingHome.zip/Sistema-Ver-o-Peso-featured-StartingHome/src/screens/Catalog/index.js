import react from "react"
import { ScrollView, StyleSheet, Text, Dimensions, View, Image } from "react-native"

import Button from "../../components/Button.js"

import TitleText from "../../components/TitleText.js"
import ItemCards from "./components/ItemCards.js"


export default function CatalogScreen({ navigation }) {

    return (<View style={styles.body}>
        <ItemCards/>
    </View>

)
}

const styles = StyleSheet.create({

    body:{
        backgroundColor: '#FFF1E2'
    },

})