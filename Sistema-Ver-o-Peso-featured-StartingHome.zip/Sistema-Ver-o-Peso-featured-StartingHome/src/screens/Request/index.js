import React from "react";
import { ScrollView, StyleSheet, View } from "react-native";
import Button from "../../components/Button";
import ButtonConfirm from "../../components/ButtonConfirm";
import ButtonDiscard from "../../components/ButtonDiscard";
import ButtonMakePublic from "../../components/ButtonMakePublic";
import InputText from "../../components/InputText";
import InputTextRequest from "../../components/InputTextRequest";
import InputTextSearch from "../../components/InputTextSearch";
import TitleText from "../../components/TitleText";

export default function RequestScreen({navigation}) {

    return (<ScrollView style={{backgroundColor: '#FFF1E2'}}>
            
    <View style={styles.body}>
        <View style={styles.login}>
            <TitleText content={"TITLE"}/>
            <InputText placeholder={"Add a Title"}/>
            <TitleText content={"ABOUT"}/>
            <InputTextRequest placeholder={"Tell us about it"}/>
            <TitleText content={"TAGS:"}/>
            <InputTextSearch placeholder={"Search for tags"}/>
            <TitleText content={"OPTIONS"}/>    
        </View>
        
        <View style={styles.buttonRow}>
            <ButtonDiscard title="Discard" />
            
            <ButtonMakePublic title="Make Public" />
        </View>
    </View>
    <View style={styles.buttonConfirmRow}>
            <View style={styles.button}>
                <ButtonConfirm title="Confirm" />
            </View>
        </View>
</ScrollView>)

}

const styles = StyleSheet.create({
    
    body:{
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: '#FFF1E2'
    },
    login:{
        alignItems: "flex-start",
        marginTop:20,
    },  
    buttonRow:{
        flexDirection: "row",
        alignItems: 'center',
        paddingLeft: 80,
        marginRight: 80
    },
    buttonConfirmRow: {
        flexDirection: "row-reverse",
        paddingTop: 20,
    },
    button:{
        padding:10
    },
})