import userCarlos from '../../assets/feed/userCarlos.png';
import userJoana from  '../../assets/feed/userJoana.png';

const publish= {
    title: "MOST RECENT",
    publication: 
    [
        {   
            image: userCarlos,
            userName: "Carlos Reis",
            descriptionUser: "Food Seller - 40m",
            titleComment: "She's Leaving Home",
            comment: "Wednesday morning at five o'clock as the day begins, silently closing her bedroom door, Leaving the note that she hoped would say more.",
        },

        {
            image: userJoana,
            userName: "Joana Silva",
            descriptionUser: "Food Seller - 2hr",
            titleComment: "Soma",
            comment: "Tried it once and they liked it and tried to hide it. Says, I've been doing this twenty-five years. Well, I'm not listening no more."
        }
    ]
} 
   

export default publish;