import AsyncStorage from '@react-native-async-storage/async-storage';
import api from "../api"

//define o token
export async function login(Email, Password){
    try{
        const login = await api.post('/login',{
            email: "seller@mail.com",
	        password: "test"
        })

        const token = login.data['token'];

        await AsyncStorage.setItem(`@token`, token) 

        return {
            token
        }
    }
    catch (error){
        console.log(error)
        return {}
    }
}

//Retorna usuario logado
export async function authenticated(){
    try{

        const auth = await api.get( 
            '/login'
        )

        const seller = auth.data
        

        return {
            seller
        }
    }
    catch (error){
        console.log(error)
        return {}
    }
}
