import React from 'react';
import { Platform, StyleSheet, View, Text, Image, Pressable } from 'react-native';
import NormalText from './NormalText';

export default function Item({name, image, rating, listPrice, onPress}) {
    return (
        <Pressable style={styles.card} onPress={onPress}>
            <View style={styles.cardContent}>
                <Image source={image} style={styles.image}/>
                <View style={styles.textColumn}>
                    <Text style={styles.text}>{ name }</Text>
                    <Text style={styles.price}>{ listPrice }</Text>
                </View>
            </View>
        </Pressable>
  );
}

const styles = StyleSheet.create({
    card: {
        borderRadius: 6,
        elevation: 3,
        backgroundColor: "#964D00",
        
        shadowColor: 'rgba(150, 77, 0, 0.5)',
        shadowOffset: { width: 0, height: 2 },
        shadowRadius: 10,
        height: 84,
        marginVertical: 10,
        marginHorizontal: 15,
    },
    cardContent: {
        flexDirection:"row",
        paddingHorizontal:10,
        paddingVertical:10,
    },
    image:{
        width: 64,
        height: 64,
        borderRadius: 5,
    },
    textColumn:{
        paddingVertical:5,
    },
    text:{
        fontFamily: "NotoRegular",

        fontWeight:'200',
        fontSize: 20,
        lineHeight: 21,
        color: '#FFF1E2',
        marginHorizontal: 15,
        marginBottom: 10,
    },
    price:{
        fontFamily: "NotoRegular",

        fontSize: 16,
        lineHeight: 21,
        color: '#FFF1E2',
        marginHorizontal: 15,
        marginBottom: 10,
    }
});