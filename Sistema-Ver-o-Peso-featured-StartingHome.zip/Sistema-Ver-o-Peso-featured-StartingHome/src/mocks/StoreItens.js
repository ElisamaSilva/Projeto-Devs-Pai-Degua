import Espresso from '../../assets/itens/photos/espresso.png'
import Mocha from '../../assets/itens/photos/mocha.png'
import Cappuccino from '../../assets/itens/photos/cappuccino.png'
import Affogato from '../../assets/itens/photos/affogato.png'
import Macchiato from '../../assets/itens/photos/macchiato.png'
import Ristretto from '../../assets/itens/photos/ristretto.png'

import GreenTea from '../../assets/itens/photos/greenTea.png'
import Mango from '../../assets/itens/photos/mango.png'
import Chocolate from '../../assets/itens/photos/chocolate.png'

import Black from '../../assets/itens/photos/black.png'
import Green from '../../assets/itens/photos/green.png'


const StoreItens = {
    StoreItensList:[
        {
            title:"Coffees",
            ItensList:[
                {
                    name: "Espresso",
                    rating: 4.8,
                    listPrice: "List price: $7,00",
                    image: Espresso
                },
                {
                    name: "Mocha",
                    rating: 4.0,
                    listPrice: "List price: $11,00",
                    image: Mocha
                },
                {
                    name: "Cappuccino",
                    rating: 3.5,
                    listPrice: "List price: $9,75",
                    image: Cappuccino
                },
                {
                    name: "Affogato",
                    rating: 3.2,
                    listPrice: "List price: $13,25",
                    image: Affogato
                },
                {
                    name: "Macchiato",
                    rating: 3.0,
                    listPrice: "List price: $8,50",
                    image: Macchiato
                },
                {
                    name: "Ristretto",
                    rating: 3.0,
                    listPrice: "List price: $7,75",
                    image: Ristretto
                }
            ]
            
        },
        {
            title:"frappuccinos",
            ItensList:[
                {
                    name: "Green Tea",
                    rating: 4.8,
                    listPrice: "List price: $13,25",
                    image: GreenTea
                },
                {
                    name: "Mango",
                    rating: 4.8,
                    listPrice: "List price: $17,00",
                    image: Mango
                },
                {
                    name: "Chocolate",
                    rating: 4.5,
                    listPrice: "List price: $14,75",
                    image: Chocolate
                }
            ]
        },
        {
            title:"Tea",
            ItensList:[
                {
                    name: "Black",
                    rating: 4.9,
                    listPrice: "List price: $8,25",
                    image: Black
                },
                {
                    name: "Green",
                    rating: 4.8,
                    listPrice: "List price: $7,00",
                    image: Green
                }
            ]
        },
    ]
};

export default StoreItens;