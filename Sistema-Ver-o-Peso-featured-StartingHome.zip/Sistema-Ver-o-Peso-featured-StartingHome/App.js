
import { StyleSheet, Image} from 'react-native';
import { NavigationContainer } from '@react-navigation/native';

import { createStackNavigator } from '@react-navigation/stack';

import ButtonRound from "./src/components/ButtonRound.js"


import StartingScreen from './src/screens/Starting';
import SignUpScreen from './src/screens/SignUp';
import LoginScreen from './src/screens/Login/index.js';
import AboutScreen from './src/screens/About';
import Feed from './src/screens/Feed/index.js';

import * as RootNavigation from './src/services/nav.js';
import { navigationRef } from './src/services/nav.js';
import RequestScreen from './src/screens/Request';
import RequestDetailsScreen from './src/screens/RequestDetails';
import PublicRequestScreen from './src/screens/PublicRequest';
import RequestFeed from './src/screens/Feed/RequestFeed/index.js';
import userCarlos from './assets/feed/userCarlos.png'


export default function App() {
  const Stack = createStackNavigator();

  return(

    <NavigationContainer  ref={navigationRef}>
      <Stack.Navigator initialRouteName="STARTING">
        <Stack.Screen name="STARTING" component={StartingScreen} 
          options={{
            headerShown: false,
        }}/>
        <Stack.Screen name="LOGIN" component={LoginScreen}
          options={{
            headerLeft: () => (
              <ButtonRound content={"chevron-left"} onPress={() => RootNavigation.navigate('STARTING')}/>
            ),
            headerTintColor: '#964D00',
            headerTitleAlign: 'center',
            headerTitleStyle: {
            fontFamily: "NotoDisplayRegular",
            fontSize: 20, 
            },
            headerShadowVisible: false,
            headerStyle: {
              //headerShown: false,
              backgroundColor: '#FFF1E2',
            }
        }}/>
        <Stack.Screen name="SIGNUP" component={SignUpScreen}
          options={{
            headerLeft: () => (
              <ButtonRound content={"chevron-left"} onPress={() => RootNavigation.navigate('LOGIN')}/>
            ),
            headerTintColor: '#964D00',
            headerTitleAlign: 'center',
            headerTitleStyle: {
              fontFamily: "NotoDisplayRegular",
              fontSize: 20, 
            },
            headerShadowVisible: false,
            headerStyle: {
              headerShown: false,
              backgroundColor: '#FFF1E2',
            }
        }}/>

        <Stack.Screen name="FEED" component={Feed}
        options={{
          headerLeft:()=>(
            <ButtonRound content={"chevron-left"} onPress={()=> RootNavigation.navigate('LOGIN')}/>
          ),
          headerRight:()=>(
            <Image source={userCarlos} style={styles.img}/>
          ),
          headerTintColor: '#964D00',
          headerTitleAlign: 'center',
          headerTitleStyle: 
          {
            fontFamily: 'NotoDisplayRegular',
            fontSize: 20,
          },
          headerShadowVisible: false,
          headerStyle:
          {
            headerShown: false,
            backgroundColor: '#FFF1E2',
          }
        }}

        />

    <Stack.Screen name="REQUEST_FEED" component={RequestFeed}
              options={{
                headerLeft: () => (
                  <ButtonRound content={"chevron-left"} onPress={() => RootNavigation.navigate('STARTING')}/>
                ),
                headerTintColor: '#964D00',
                headerTitleAlign: 'center',
                headerTitleStyle: {
                  fontFamily: "NotoDisplayRegular",
                  fontSize: 20, 
                },
                headerShadowVisible: false,
                headerStyle: {
                  headerShown: false,
                  backgroundColor: '#FFF1E2',
                },
            }}
    />
  

    <Stack.Screen name="ABOUT" component={AboutScreen} 
              options={{
                headerLeft: () => (
                  <ButtonRound content={"chevron-left"} onPress={() => RootNavigation.navigate('STARTING')}/>
                ),
                headerTintColor: '#964D00',
                headerTitleAlign: 'center',
                headerTitleStyle: {
                  fontFamily: "NotoDisplayRegular",
                  fontSize: 20, 
                },
                headerShadowVisible: false,
                headerStyle: {
                  headerShown: false,
                  backgroundColor: '#FFF1E2',
                },
            }}/>

            <Stack.Screen name="REQUEST_DETAILS" component={RequestDetailsScreen} 
              options={{
                headerLeft: () => (
                  <ButtonRound content={"chevron-left"} onPress={() => RootNavigation.navigate('')}/>
                ),
                headerRight: () => (
                  <ButtonRound content={"user"}/>
                ),
                title: 'REQUEST',
                headerTintColor: '#964D00',
                headerTitleAlign: 'center',
                headerTitleStyle: {
                  fontFamily: "NotoDisplayRegular",
                  fontSize: 20, 
                },
                headerShadowVisible: false,
                headerStyle: {
                  headerShown: false,
                  backgroundColor: '#FFF1E2',
                },
            }}/>

        <Stack.Screen name="REQUEST" component={RequestScreen} 
              options={{
                headerLeft: () => (
                  <ButtonRound content={"chevron-left"} onPress={() => RootNavigation.navigate('FEED')}/>
                ),
                headerRight: () => (
                  <ButtonRound content={"user"}/>
                ),
                headerTintColor: '#964D00',
                headerTitleAlign: 'center',
                headerTitleStyle: {
                  fontFamily: "NotoDisplayRegular",
                  fontSize: 20, 
                },
                headerShadowVisible: false,
                headerStyle: {
                  headerShown: false,
                  backgroundColor: '#FFF1E2',
                },
            }}/>

    <Stack.Screen name="PUBLIC_REQUEST" component={PublicRequestScreen} 
              options={{
                headerLeft: () => (
                  <ButtonRound content={"chevron-left"} onPress={() => RootNavigation.navigate('FEED')}/>
                ),
                headerRight: () => (
                  <ButtonRound content={"user"}/>
                ),
                title: 'REQUEST',
                headerTintColor: '#964D00',
                headerTitleAlign: 'center',
                headerTitleStyle: {
                  fontFamily: "NotoDisplayRegular",
                  fontSize: 20, 
                },
                headerShadowVisible: false,
                headerStyle: {
                  headerShown: false,
                  backgroundColor: '#FFF1E2',
                },
            }}/>
            
        </Stack.Navigator>
      </NavigationContainer>
      
     
      
   
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 2,
  },

  img: 
  {
    margin: 10,
    marginHorizontal: 8
  }
});
