import React from "react";
import { View } from "react-native";
import NormalText from "../components/NormalText";
import PublishedByRequest from "../components/PublishedByRequest";

export default function ChatMessage({message}) {
    console.log(message);

    return (<View>
        <PublishedByRequest request={message.author} />
        <NormalText content={message.content} />
    </View>);
}