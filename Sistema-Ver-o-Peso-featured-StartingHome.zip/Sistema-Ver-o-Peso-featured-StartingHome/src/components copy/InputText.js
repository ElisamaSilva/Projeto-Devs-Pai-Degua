import react from 'react'; 
import reactDom from 'react-dom';
import { Platform, TextInput, StyleSheet } from 'react-native'

export default function InputText({ placeholder }) {   
  const [filter, setFilter] = react.useState('');

  let hidePass = false

  if (placeholder === 'Your Password'){
    hidePass = true
  } 
  
  return (
    <TextInput
      placeholder={placeholder}
      style={styles.input}
      onChange={event => setFilter(event.nativeEvent.text)}
      value={filter}
      blurOnSubmit={true}
      secureTextEntry={hidePass ? true : false}
    />   
  ); 
}

const styles = StyleSheet.create({
  input: {
    height: 45,
    width: 300,

    marginHorizontal: 15,
    marginVertical: 5,
    padding: 15,

    borderRadius: 8,
    borderWidth:1.7,
    borderColor: "#964D00",

    backgroundColor: '#FFF1E2',
    color:"#7d561a",

    ...Platform.select({
      web: {
        placeholderTextColor:"rgba(150, 77, 0, 0.2)",
      },
      ios: {
        placeholderTextColor:"rgba(150, 77, 0, 0.2)",
        outlineColor:"#7d561a",
      }
    }),
    

    shadowColor: "#c2a880",
    shadowOffset: { width: 0, height: 0 },
    shadowRadius: 10,
  },
});

