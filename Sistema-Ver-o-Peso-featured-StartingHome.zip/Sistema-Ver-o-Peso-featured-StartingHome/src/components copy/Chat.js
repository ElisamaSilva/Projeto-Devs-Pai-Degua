import React from "react";
import { FlatList, Image, View } from "react-native";
import NormalText from "./NormalText";
import ChatMessage from "./ChatMessage";
import PublishedByRequest from "./PublishedByRequest";

export default function Chat({chat}) {

      return <FlatList
          data = { chat }
          renderItem = {({ item }) => <ChatMessage message={item}/>}
          
        />
}