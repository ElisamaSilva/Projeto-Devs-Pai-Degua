import react from "react"
import { ScrollView, StyleSheet, Text, Dimensions, View, Image } from "react-native"

import userPhoto from '../../../assets/user/userPhoto.png'

import Button from "../../components/Button.js"

import InputText from "../../components/InputText"
import TitleText from "../../components/TitleText.js"

const width = Dimensions.get('screen').width



export default function SignUpScreen({ navigation }) {
    return (
        <ScrollView style={{backgroundColor: '#FFF1E2'}}>
            
            <View style={styles.body}>
                <Image source={userPhoto} style={styles.userPhoto}/>
                <View style={styles.login}>
                    <TitleText content={"Name"}/>
                    <InputText placeholder={"Your name"}/>
                    <TitleText content={"Email"}/>
                    <InputText placeholder={"Your email address"}/>
                    <TitleText content={"Password"}/>
                    <InputText placeholder={"Your password"}/>
                    <TitleText content={"Number"}/>
                    <InputText placeholder={"Your phone number"}/>
                </View>
                
                <View style={styles.buttonRow}>
                    <View style={styles.button}>
                        <Button title="Sign In" 
                                onPress={() => navigation.navigate('LOGIN')}/>
                    </View>
                </View>
            </View>
        </ScrollView>
    )
}

const styles = StyleSheet.create({
    userPhoto:{
        width:84,
        height:84,
        alignItems: "center"
    },
    login:{
        alignItems: "flex-start",
        marginTop:20,
    },
    body:{
        alignItems: 'center',
        justifyContent: 'center',
        marginTop:50,
    },
    buttonRow:{
        alignItems: 'center',

        padding: 20
    },
    button:{
        padding:10
    }
})