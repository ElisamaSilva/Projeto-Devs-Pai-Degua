import React, { useEffect, useState } from "react";
import { FlatList, ScrollView, StyleSheet, View } from "react-native";
import NormalText from "../../components/NormalText";
import TitleText from "../../components/TitleText";

import { loadRequestDetails } from "../../services/loadFiles.js";
import { Image } from "react-native";
import NormalTextRequest from "../../components/NormalTextRequest";
import PublishedByRequest from "../../components/PublishedByRequest";
import ProgressRequest from "../../components/ProgressRequest";
import Chat from "../../components/Chat";
import ButtonHome from "../Home/components/buttonHome";
import Tags from "../../components/Tags";
import ButtonVotes from "../../components/ButtonVotes";
import ButtonShare from "../../components/ButtonShare";

export default function PublicRequestScreen({navigation}) {
    
    const loadItem = loadRequestDetails();
    const votesTitle = loadItem.votes + " Votes"; 

    return (<ScrollView style={{backgroundColor: '#FFF1E2'}}>
        <View style={styles.body}>
            <View style={styles.login}>
                <TitleText content={"PUBLISHED BY"}/>
             
                <PublishedByRequest request={loadItem.seller} />
                <TitleText content={"ABOUT"}/>
                <NormalTextRequest content={loadItem.details}/>
                
                <TitleText content={"TAGS"} />
                <Tags tags={loadItem.tags}/>
                
                <TitleText content={"ANALISED BY"}/>
                <PublishedByRequest request={loadItem.agent} />
                <TitleText content={"PROGRESS"}/>
                <ProgressRequest progress={loadItem.progress}/>
                <TitleText content={"OPTIONS"}/>
                <View style={styles.buttonRow}>
                    <ButtonVotes title={votesTitle} />
                    <ButtonShare title={"Share"} />
                </View>
                <TitleText content={"COMMENTS"}/> 
                <Chat chat={loadItem.chat}/>
            </View>
        </View>
    </ScrollView>);
}

const styles = StyleSheet.create({
    
    body:{
        alignItems: 'flex-start',
        justifyContent: 'flex-start',
        backgroundColor: '#FFF1E2'
    },
    login:{
        alignItems: "flex-start",
        marginTop:20,
    },  
    buttonRow:{
        flexDirection: "row",
        alignItems: 'center',
    },
    buttonConfirmRow: {
        flexDirection: "row-reverse",
        paddingTop: 20,
    },
    button:{
        padding:10
    },

    card: {
        backgroundColor: "white",
        marginVertical: 8,
        marginHorizontal: 16,
        borderRadius: 8,
        
        elevation: 4,
        shadowColor: '#000',
        shadowOffset: {
            width: 0,
            height: 2
        },
        shadowOpacity: 0.23,
        shadowRadius: 2.62
    },
})