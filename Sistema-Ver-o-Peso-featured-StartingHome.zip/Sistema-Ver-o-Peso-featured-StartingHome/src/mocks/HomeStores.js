import oilInspired from '../../assets/stores/oilInspired.png';
import organicFood from '../../assets/stores/organicFood.png';
import spoonAndFork from '../../assets/stores/SpoonAndFork.png';
import saborBarista from '../../assets/stores/saborBarista.png';


const randDistance = (min,max) =>{
    return Math.floor(Math.random() * (max - min + 1) + min);
};

const stores = {
    title:"Stores",
    list:[
        {
            name: "Sabor Barista",
            image: saborBarista,
            description: "Coffee and tea...",
            rating: randDistance(1,5),
            favorite: true
        },
        {
            name: "Organic Food",
            image: organicFood,
            description: "Brazillian organic food...",
            rating: randDistance(1,5),
            favorite: false
        },
        {
            name: "Oil Inspired",
            image: oilInspired,
            description: "Essential oils...",
            rating: randDistance(1,5),
            favorite: false
        },
        {
            name: "Spoon & Fork",
            image: spoonAndFork,
            description: "Brazillian food...",
            rating: randDistance(1,5),
            favorite: false
        },
    ]
};

export default stores;