import React from "react";
import { FlatList, StyleSheet } from "react-native";
import ButtonHome from "../telas/componentes/buttonHome";

export default function Tags ({tags}) {

    return (<FlatList 
        style={styles.container}
        horizontal={true}
        data={tags}
        renderItem={({item}) => <ButtonHome title={item.name} />} />
    );
}

const styles = StyleSheet.create({
    container: {
        flexDirection: 'row',
        paddingTop: 10,
        flex: 7,
        
    } 
})