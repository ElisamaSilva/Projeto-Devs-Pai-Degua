import frontView from '../../assets/about/frontView.png'
import iron from '../../assets/about/iron.png'
import topView from '../../assets/about/topView.png'

const aboutImages = {
    imageList:[
        {
            image: frontView,
        },
        {
            image: iron,
        },
        {
            image: topView,
        },
    ]
};

export default aboutImages;