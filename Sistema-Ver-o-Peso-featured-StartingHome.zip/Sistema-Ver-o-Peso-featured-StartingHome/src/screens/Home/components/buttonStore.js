import React from "react";

import { TouchableOpacity, StyleSheet, View, Text, Image } from 'react-native';
import barracaLogo from '../../../../assets/barraca_logo.png'


export default function ButtonStore({title, img, description, onPress}){
    return<>
        <TouchableOpacity style = {styles.botaoEstilo} onPress = {onPress}>
        <View style= {styles.buttonIconView}>
            <Image source = {img} style = { styles.botaoLojaImage}></Image>
            <Text style = {styles.textButtonStore}>{title}</Text>
            <Text style = {styles.textDescription}>{description}</Text>
        </View>
        </TouchableOpacity>
    </>
}

const styles = StyleSheet.create({
    botaoLojaImage: {
        padding: 16, 
        margin: 5,

        height: 25, 
        width: 25, 
        resizeMode: 'stretch', 
    },
    buttonIconView: { 
        //width: 1, 
        height: 40, 
        //backgroundColor: '#fff',
        flexDirection: 'row',
        width: '100%',

        resizeMode: 'stretch', 
        right: "10%",
    },
    buttonIconView: { 
        height: 60, 
        flexDirection: 'row',
        width: "100%",

        height: '100%',
        alignItems: "center",
    },
    textButtonStore: {

        flexDirection: 'column',
        textAlign: "center",
        fontSize: 16,
        alignItems: "center",
        color: "white",

        flexDirection: 'row',
        fontSize: 22,
        color: "white",
        fontFamily: "NotoRegular",
        
    },

    botaoEstilo: {
        flexDirection: 'row',  
        backgroundColor: '#964D00', 
        borderWidth: 0.5, 
        borderColor: '#fff',  
        borderRadius: 15, 
        width: 'auto',
        margin: 10,
        padding: 16,
        flex: 6,

    },



    textDescription: {
        fontSize: 14,
        fontFamily: "NotoRegular",
        padding: 16,
        position: "relative",
        flexDirection: "column",
        marginTop: 18,
        right: "210%",
        color: "white"
    }


})