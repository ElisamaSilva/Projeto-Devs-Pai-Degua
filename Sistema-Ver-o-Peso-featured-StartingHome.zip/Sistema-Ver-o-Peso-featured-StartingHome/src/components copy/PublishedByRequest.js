import React from "react";
import { Image, StyleSheet, View } from "react-native";
import NormalText from "../components/NormalText";
import TitleText from "../components/TitleText";

import userImage from "../../assets/Persona.png";

export default function PublishedByRequest({request}) {
    const ocupationPosted = request.ocupation + ' \u00B7 ' + request.posted;

    const png = request.photo;

    return (<View style={styles.container}>
        <Image source={request.photo} style={styles.userImage}/>
        <View>
            <NormalText content={request.name}/>
            <NormalText content={ocupationPosted}/>
        </View>
    </View>);
}

const styles = StyleSheet.create({
    userImage: {
        width: 50, 
        height: 50, 
        borderRadius: 200 / 2, 
        marginLeft: 10
    },
    container: {
        flexDirection: 'row'
    },
})