import React from 'react'
import { TouchableOpacity, StyleSheet } from 'react-native'
import { FontAwesome5} from '@expo/vector-icons'
export default function Comment({onPress}){
    return<>
    <TouchableOpacity style={styles.comment} onPress={onPress}>
    <FontAwesome5 name="comments" size={24} color="#964D00" />
    </TouchableOpacity>
   
    </>
}

const styles = StyleSheet.create({
    comment: 
    {
        padding: 16, 
        marginHorizontal: 25,
    }
})
 
