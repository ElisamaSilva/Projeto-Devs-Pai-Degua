import React, { useState, useEffect } from 'react';

import {
    StyleSheet,
    View,
    Text,
    TouchableOpacity,
    TextInput, Image
} from 'react-native';

export default function Searchbar({ value, updateSearch, style, onPress }) {

    const [query, setQuery] = useState();
    const [error, setError] = useState()
    return (
        <View style={{flexDirection:'row'}}>
            <View style={styles.searchContainer}>
                <View style={styles.vwSearch}>
                    <Image
                        style={styles.icSearch}
                        />
                </View>

                <TextInput
                    value={query}
                    placeholder="Quick Search..."
                    style={styles.textInput}
                    onChangeText={(text) => {
                        var letters = /^$|^[a-zA-Z._\b ]+$/;
                        if (text.length > 12)
                            setError("Query too long.")
                        else if (text.match(letters)) {
                            setQuery(text)
                            updateSearch(text)
                            if (error)
                                setError(false)
                        }
                        else setError("Please only enter alphabets")
                    }}
                />
                {
                    query ?
                        <TouchableOpacity
                            onPress={() => setQuery('')}
                            style={styles.vwClear}>
                            <Image
                                style={styles.icClear}
                                 />
                        </TouchableOpacity>
                        : <View style={styles.vwClear} />
                }

            </View>
            {
                error &&
                <Text style={styles.txtError}>
                    {error}
                </Text>
            }
             
        </View >
    )
}
const styles = StyleSheet.create({
   
   
    textInput: {
       
        flex: 1,
    },

    vwSearch: {
        flex: 0.2,
        justifyContent: 'center',
        alignItems: 'center',
        // width: 40,
        // backgroundColor: 'red'
    },
    icSearch: {
        //height: 18, width: 18
    },
    searchContainer:
    {
        backgroundColor: 'white',
        width: "88%",
        height: 50,
        flexDirection: 'row',
        borderRadius: 8,
        marginTop: 20,
        left: 20,
        
    

    },
    
});