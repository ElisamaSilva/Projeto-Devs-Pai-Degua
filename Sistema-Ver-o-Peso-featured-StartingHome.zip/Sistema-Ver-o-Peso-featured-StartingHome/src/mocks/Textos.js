
const texto = {
    menu: {
        titulo: "Ver-o-Peso",
        botaoStart: "Start",
        botaoAbout: "About",

    }
}

export default texto;