import React from "react"
import { ScrollView, Text, Dimensions, View, Image, TouchableOpacity, StyleSheet } from "react-native"

import saborBarista from '../../../assets/stores/saborBarista.png'
import oilInspired from '../../../assets/stores/oilInspired.png'
import organicFood from '../../../assets/stores/organicFood.png'
import spoonAndFork from '../../../assets/stores/spoonAndFork.png'

import Slider from './components/Slider.js'
import ButtonStore from './components/buttonStore.js'
import ButtonHome from './components/buttonHome.js'

import TitleText from "../../components/TitleText";
import Item from "../../components/Item.js";
import * as RootNavigation from '../../services/nav.js';

const width = Dimensions.get('screen').width

export default function HomeScreen({ navigation }) {
    return (

    <ScrollView style = {styles.container}>

        <View style = {{flexDirection: 'row'}}>
            <TouchableOpacity onPress={()=>navigation.navigate('Welcome')}>
            </TouchableOpacity>
        </View>
        <Slider />
        <View style = {{flex: 7, flexDirection: "row", paddingTop: 10}}>
            
            <ButtonHome title="Oils" />
            <ButtonHome title="Artesanato"/>
            <ButtonHome title="Snacks"/>
        </View>

        <TitleText content={"Stores"} />
        <Item name={"Sabor Barista"} image={saborBarista} listPrice={"Coffee & tea..."} onPress={() => RootNavigation.navigate('SaborBarista')}/>
        <Item name={"Oil Inspired"} image={oilInspired} listPrice={"Essential oils..."} />
        <Item name={"Organic Food"} image={organicFood} listPrice={"Brazillian organic food..."} />
        <Item name={"Spoon & Fork"} image={spoonAndFork} listPrice={"Brazillian food..."} />
    </ScrollView>
    )
}

const styles = StyleSheet.create({
    container: {
        backgroundColor: "#FFF1E2",
        heigh: '100%'
    },
})