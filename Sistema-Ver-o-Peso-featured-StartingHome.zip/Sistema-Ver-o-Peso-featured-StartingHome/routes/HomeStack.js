import {createStackNavigator} from 'react-navigation-stack';
import {CreateAppContainer} from 'react-navigation'
import { createNativeStackNavigator } from '@react-navigation/native-stack/lib/commonjs';
import Start from '../src/telas/Starting'
import Home from '../src/telas/Home'
const screens = {
    Start: {
        screen: Start
    },
    Home: {
        screen: Home
    },
}
const HomeStack = createNativeStackNavigator(screens);

export default CreateAppContainer(HomeStack);