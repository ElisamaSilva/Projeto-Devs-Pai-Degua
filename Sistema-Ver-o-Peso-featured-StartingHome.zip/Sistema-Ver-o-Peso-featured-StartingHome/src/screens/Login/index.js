import React from "react"
import { ScrollView, StyleSheet, Text, Dimensions, View, Image } from "react-native"

import userPhoto from '../../../assets/user/userPhoto.png'

import Button from "../../components/Button.js"
import ButtonRound from "../../components/ButtonRound.js"

import InputText from "../../components/InputText"
import LinkText from "../../components/LinkText"
import TitleText from "../../components/TitleText.js"

const width = Dimensions.get('screen').width



export default function LoginScreen({ navigation }) {
    return (
        <ScrollView style={{backgroundColor: '#FFF1E2'}}>
            
            <View style={styles.body}>
                <Image source={userPhoto} style={styles.userPhoto}/>
                <View style={styles.login}>
                    <TitleText content={"Email"}/>
                    <InputText placeholder={"Your email address"}/>
                    <TitleText content={"Password"}/>
                    <InputText placeholder={"Your Password"}/>
                    <LinkText content={"Forgot the password?"}/>
                </View>
                
                <View style={styles.buttonRow}>
                    <View style={styles.button}>
                        <Button title="Sign In" 
                                onPress={() => navigation.navigate('FEED')}/>
                    </View>
                </View>
                <View style={styles.buttonRow}>
                    <View style={{flexDirection:"row"}}>
                        <ButtonRound content={"linkedin"}/>
                        <ButtonRound content={"github"}/>
                        <ButtonRound content={"facebook"}/>
                    </View>
                    <Button title="Sign Up" onPress={() => navigation.navigate('SIGNUP')}/>
                </View>
            </View>
        </ScrollView>
    )
}

const styles = StyleSheet.create({
    userPhoto:{
        width:84,
        height:84,
        alignItems: "center"
    },
    login:{
        alignItems: "flex-start",
        marginTop:20,
    },
    body:{
        alignItems: 'center',
        justifyContent: 'center',
        marginTop:50,
    },
    buttonRow:{
        alignItems: 'center',

        padding: 20
    },
    button:{
        padding:10
    }
})