import React from 'react';
import { View, Text, Image, StyleSheet, Dimensions, Platform, FlatList } from 'react-native';

import Item from '../../../components/Item.js';
import TitleText from '../../../components/TitleText.js';

import * as RootNavigation from '../../../services/nav.js';

const width = Dimensions.get('screen').width

export default function ItemCard({ title, ItensList}){

    return <View style = {styles.body}>
        <TitleText content={title}/>
        <FlatList
        data = { ItensList }
        renderItem = {({ item }) => <Item name={item.name} image={item.image} listPrice={item.listPrice} onPress={() => RootNavigation.navigate('ITEM')}/>}
        keyExtractor = {({name}) => name}/>
    </View>
};

const styles = StyleSheet.create({
    body:{
        width:"100%"
    }
})