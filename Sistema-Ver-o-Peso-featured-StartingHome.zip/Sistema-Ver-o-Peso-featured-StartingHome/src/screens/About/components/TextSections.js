import React , { useEffect, useState } from 'react';
import { Dimensions, Image, FlatList, StyleSheet, Platform } from 'react-native';

import { loadAboutText } from '../../../services/loadFiles.js';
import TextSection from './TextSection.js';

import frontView from '../../../../assets/about/frontView.png'

const width = Dimensions.get('screen').width

export default function TextSections({ }) {   
  const [contentList, setList] = useState([]);

  useEffect(() => {
      const loadItem = loadAboutText();
      setList(loadItem.contentList);
  }, []);

  const listHeader = () => {
    return <>
        <Image source={frontView} style={styles.banner}/>
    </>
    }

  return <FlatList
      data = { contentList }
      renderItem = {({ item }) => <TextSection {...item}/>}
      keyExtractor = {({title}) => title}
      ListHeaderComponent = {listHeader} 
    />

};

const styles = StyleSheet.create({
    banner:{
        marginVertical: 16,
        marginHorizontal:16,
        ...Platform.select({
            web: {
                width: "100%",
                height: 299,
                
            },
            android: {
                width: "100%",
                height: 578 / 768 * width,
            },
    
        }),
    }
})