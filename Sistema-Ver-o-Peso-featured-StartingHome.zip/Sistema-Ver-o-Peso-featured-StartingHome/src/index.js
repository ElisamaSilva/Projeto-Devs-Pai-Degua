import Start from './telas/Starting';
import Home from './telas/Home';
import Login from './telas/login';
import SingUp from './telas/SingUp';


export {Start, Home, Login, SingUp};

import SaborBarista from './telas/StoreSaborBarista';
export {Start, Home, Login, SingUp, SaborBarista};


