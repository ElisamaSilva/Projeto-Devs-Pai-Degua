import React from 'react';140
import { StyleSheet, Pressable } from 'react-native';
import { Icon } from 'react-native-elements';

export default function ButtonRound({ onPress, content }) {
  return (
    <Pressable style={styles.button} onPress={onPress}>
      <Icon name={ content }  size={20} color="#FFF1E2"  type='feather' />
    </Pressable>
  );
}



const styles = StyleSheet.create({
  button: {
    alignItems:'center',
    justifyContent:'center',
    width:40,
    height:40,
    backgroundColor:'#964D00',
    borderRadius:50,

    margin:10,

    shadowColor: 'rgba(150, 77, 0, 0.7)',
    shadowOffset: { width: 0, height: 2 },
    shadowRadius: 10,
  }
});