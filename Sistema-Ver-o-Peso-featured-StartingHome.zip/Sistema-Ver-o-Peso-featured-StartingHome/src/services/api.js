import axios from "axios"
import AsyncStorage from '@react-native-async-storage/async-storage';

const api = axios.create({
    baseURL: "http://159.89.235.253:3333/"
})


api.interceptors.request.use(async (config) => {
    try{
        const token = await AsyncStorage.getItem('@token')

        if(token) {
            config.headers.Authorization = `Bearer ${token}`;
        }

        return config
    } catch (error) {
        console.log(error)
    }
});



export default api;