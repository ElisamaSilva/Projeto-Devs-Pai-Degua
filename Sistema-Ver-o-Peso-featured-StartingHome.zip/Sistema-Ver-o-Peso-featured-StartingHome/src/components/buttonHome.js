import { StyleSheet, TouchableOpacity,Text, View } from 'react-native';
import React from 'react';



export default function ButtonHome({ title }){ 
    return <>
    
     <TouchableOpacity style = {styles.button}>
        <Text style = { styles.textButton }>{ title }</Text>
     </TouchableOpacity>
   
     </>
}

const styles = StyleSheet.create({
    button: {
        padding: 16,
        backgroundColor: '#964D00',

        borderRadius: 20,
        marginTop: 20,
        width: "28%",
        margin: 10,
        left: 2,

        

        borderRadius: 30,
        marginTop: 20,
        width: "28%",
        margin: 10,
        left: 2,
        width:164,
        height:50,
        alignItems: 'center',
        justifyContent: 'center',
  
    },
        
        textButton: {
            textAlign: "center",
            fontSize: 16,

            color: "white",

            color: "white",
            fontFamily: "NotoRegular",

        }
           
    })
