import React from "react"
import { Text, StyleSheet } from "react-native"

export default function TitleText( {content} ) {
    return (
    <Text style={styles.content}>{ content.toUpperCase() }</Text>
    )
}

const styles = StyleSheet.create({
    content: {
        fontFamily: "NotoDisplayRegular", 
        fontSize: 20, 
        color: "#964D00",
        marginHorizontal: 15,
        marginVertical: 5,
    },
})