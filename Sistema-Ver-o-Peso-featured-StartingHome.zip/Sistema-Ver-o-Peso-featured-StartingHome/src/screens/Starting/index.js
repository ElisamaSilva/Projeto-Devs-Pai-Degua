import react from "react"
import { View } from "react-native"


import NewsList from "./components/NewsList.js";

export default function StartingScreen({ navigation }) {
    return (
        <View style={{backgroundColor: '#FFF1E2'}}>
            <NewsList navigation={navigation}/>
        </View>
    )
}

