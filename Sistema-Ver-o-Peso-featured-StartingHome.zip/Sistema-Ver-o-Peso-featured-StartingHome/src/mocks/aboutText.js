import map from '../../assets/about/map.png'


const aboutText = {
    contentList:[
        {
            title: "VER-O-PESO",
            content: "One of the tourist attractions in the city of Belém, the mercado do ver-o-peso is the largest open-air fair in Latin America, including as well the doca das embarcações, the praça do pescador and the mercado de ferro."
        },
        {
            title: "LOCATION",
            image: map,
            content: "Belém do Pará, Pará, Brasil.\nBlvd. Castilhos França - Campina, Belém - PA, 66013-030"
        },
        {
            title: "HOURS",
            content: "Monday-saturday: 05:00 - 18:30\nSunday: Closed"
        },
    ]
};

export default aboutText;