import React, { useState } from "react";
import { Dimensions, FlatList, Image, View, StyleSheet, Platform} from "react-native";


const {width} = Dimensions.get('window');

import mercado1 from '../../../../assets/home/Carrosel_Img.png';
import mercado2 from '../../../../assets/home/Carrosel_Img01.png';
import mercado3 from '../../../../assets/home/Carrosel_Img02.png';

const items = [
    {
      id: 1,
      url: mercado1
    },
    {
      id:2,
      url: mercado2
    },
    {
      id:3,
      url: mercado3
    }
]

const OnBoardingItem = ({item}) => {
    return (
      <Image source={item.url} style={styles.image} />
    )
  }
  
  export default function Slider() {
    const [activeIndex, setActiveIndex] = useState(0);
  
    return <View style={styles.container}>
        <FlatList
          data={items}
          style={{maxHeight:width}}
          onMomentumScrollEnd={(event) => {
            setActiveIndex(parseInt(event.nativeEvent.contentOffset.x)/parseInt(width))
          }}
          pagingEnabled
          horizontal
          showsHorizontalScrollIndicator={false}
          keyExtractor={(item) => String(item?.id)}
          renderItem={({item}) => <OnBoardingItem item={item} />}
        />
        {
          items.length > 1 ? 
            <View style={styles.dotsContainer}>
              {
                items.map((key,i) => (
                  <View
                    style={[styles.dot, {backgroundColor: i === activeIndex ? 'blue' : 'grey'}]}
                  />
                ))
              }
            </View>     
          : null
        }
    </View>
  }

  const styles = StyleSheet.create({
    container: {
        backgroundColor: "#FFF1E2",
        heigh: '100%'
    },
    image:{
      width: width,
    }
})